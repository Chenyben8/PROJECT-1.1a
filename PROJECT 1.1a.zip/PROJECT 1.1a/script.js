 let currentSlide = 0;
const slide = document.querySelectorAll('.gallery-container img');
const numSlides = slide.lenght;

function showSlide(index) {
    const gallery = document.querySelector('.gallery-container');
    const slideWidth = slide[0].clientWidth;
    if (index < 0) {
        index = numSlides - 1;
    } else if (index >= numSlides) {
        index = 0;
    }
    gallery.style .transform = 'translateX(${-index * slideWidth}px)';
    currentSlide = index;
}
function prevSlide() {
    showSlide(currentSlide - 1);
}
function nextSlide(){
    showSlide(currentSlide + 1);
}
showSlide(currentSlide);